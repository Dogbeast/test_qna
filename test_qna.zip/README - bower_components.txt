bower_components is required and located one level above the project root folder.
angular, angular-cookies, and angular-route was used via bower

Instructions:

<WHILE IN PROJECT ROOT DIRECTORY>
cd ..
bower install angular angular-cookies angular-route --save